#include<isotream>
using namespace std;

class Human{
    public:
    int height;
    int age;
    int weight;
    public:
    int getAge(){
        return this->Age;


    }
    int setWeight(int w){
        this->weight=w;
    }
};
class Male: public Human{
    public:
    string color;
    void sleep(){
        cout<<"Male Sleeping"<<endl;
    }
};

int main(){
    male obj1;
    cout<<obj1.age<<endl
    cout<<obj.weight<<endl;
    return 0;
}